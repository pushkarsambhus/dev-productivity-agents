"""
05_topological_sort.py
----------------------
Goal: Given dependency edges in a Directed Acyclic Graph (DAG), return a valid topological order.
Also detect cycles and raise an error if they exist.

Why this matters:
- Many build/test/data pipelines are DAGs.
- Interviewers test your ability to reason about graphs and cycle detection.
"""

from collections import defaultdict, deque
from typing import List, Tuple

def topological_sort(num_nodes: int, edges: List[Tuple[int, int]]) -> List[int]:
    """
    :param num_nodes: number of nodes labeled 0..num_nodes-1
    :param edges: list of (u, v) meaning u -> v (u must come before v)
    :return: a list of nodes in a valid order

    We use **Kahn's algorithm**:
    - Compute indegree (how many incoming edges each node has).
    - Start with nodes of indegree 0.
    - Repeatedly remove them and decrement neighbors' indegrees.
    - If we processed fewer than num_nodes, there is a cycle.
    """
    indegree = [0] * num_nodes
    graph = defaultdict(list)
    for u, v in edges:
        graph[u].append(v)
        indegree[v] += 1

    q = deque([i for i in range(num_nodes) if indegree[i] == 0])
    order = []

    while q:
        u = q.popleft()
        order.append(u)
        for v in graph[u]:
            indegree[v] -= 1
            if indegree[v] == 0:
                q.append(v)

    if len(order) != num_nodes:
        raise ValueError("Graph has at least one cycle; no topological order exists.")
    return order


if __name__ == "__main__":
    # Example DAG: 0->2, 1->2, 2->3
    edges = [(0,2), (1,2), (2,3)]
    print("Order:", topological_sort(4, edges))

    # Example with a cycle: 0->1, 1->2, 2->0
    try:
        print(topological_sort(3, [(0,1),(1,2),(2,0)]))
    except ValueError as e:
        print("Cycle detected:", str(e))
